## Layout
The designs were created to the following widths:
- Mobile: 375px
- Desktop: 1440px


## Colors
- Green: #002e35
- Black: #000000


## Typography
- Heading font family: [Roboto Condensed](https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@700&display=swap)
- Body font family: [Open Sans](https://fonts.googleapis.com/css2?family=Open+Sans&display=swap)
